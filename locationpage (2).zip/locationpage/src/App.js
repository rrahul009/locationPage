
import './App.css';
import C from './components/c';
import Download from './components/downloadDelete';
import Upload from './components/upload';
import Save from './components/save';
import Box from '@mui/material/Box';
function App() {

  return (
    <div className="App">
   
   
   
<Upload />
<Download />
<Save />
    </div>
  );
}

export default App;
