import add from "./addReducer";
import { combineReducers } from "redux";
const rootReducer=combineReducers({
    add
})
export default rootReducer; 