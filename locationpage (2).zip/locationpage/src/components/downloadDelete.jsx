import { useSelector} from "react-redux"
import { useState } from "react"
import { updateID } from "../actions/actions"
import { useDispatch } from "react-redux"
const Download=()=>{
const data=useSelector((state)=>state.add.ids)
const dispatch=useDispatch()
// when localstroge changes , update fileID state so download button can load

console.log(data)
const handleDownload= (e)=>{
    let id=e.target.id
   // for downloading content by id
    window.location.href=`http://localhost:5000/download?id=${id}`
    
    
}
const handleDelete=(e)=>{
    let id=e.target.id
    fetch("http://localhost:5000/delete?id="+e.target.id)
    .then((res)=>{
        if(res.status===200){
            // if deleted then remove that id from redux store and its related icon
dispatch(updateID(id))
        }
    })
}
return(
    <>
<h1>file id is : </h1>
<div className="downloadSection" style={{display:"flex",flexDirection:"column"}}>
{

    data.map((id)=>{
        return(
            <>
        <p id={id} onClick={handleDelete}>DELETE</p>
            <img style={{cursor:"pointer"}} alt="download" id={id} src="https://cdn-icons-png.flaticon.com/512/3325/3325040.png" onClick={handleDownload} height="30px" width="30px" />
        </>
        )
    })

    
}
</div>
    </>
)
}
export default Download