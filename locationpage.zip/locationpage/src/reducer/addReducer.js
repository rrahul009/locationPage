const initial={
    ids:[]
}
 const add=(state=initial, action)=>{
switch(action.type){
case "set_fileID" :
    return {
        ...state,
        ids:action.payload
    }
    default : return state
}
}
export default add
