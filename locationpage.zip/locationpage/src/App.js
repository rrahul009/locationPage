
import './App.css';
import C from './components/c';
import Download from './components/downloadDelete';
import Upload from './components/upload';
function App() {

  return (
    <div className="App">
   

<Upload />
<Download />
    </div>
  );
}

export default App;
