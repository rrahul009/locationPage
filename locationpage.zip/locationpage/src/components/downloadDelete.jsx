import { useSelector} from "react-redux"

const Download=()=>{
const data=useSelector((state)=>state.add.ids)
const fileIDs=JSON.parse(localStorage.getItem("fileIDs"))
console.log(data)
const handleDownload= (e)=>{
    let id=e.target.id
   // for downloading content by id
    window.location.href=`http://localhost:5000/download?id=${id}`
    
}
return(
    <>
<h1>file id is : </h1>
<div className="downloadSection" style={{display:"flex",flexDirection:"column"}}>
{
    fileIDs!==null?
    fileIDs.map((id)=>{
        return(
        
            <img style={{cursor:"pointer"}} alt="download" id={id} src="https://cdn-icons-png.flaticon.com/512/3325/3325040.png" onClick={handleDownload} height="30px" width="30px" />
        )
    })
    :
    <></>
    
}
</div>
    </>
)
}
export default Download